/* Agent2API 词典域清单 —— 由 desktop-tauri/i18n/build.mjs 生成，请勿手改 */
window.__WB_I18N_DOMAINS = ["common", "login", "accounts", "account-settings", "add-account", "models", "routing", "agent", "tools", "settings", "assistant", "update", "keys", "proxies", "docs", "report", "checkin", "tasks", "logs", "requests", "tables", "port"];
