/* Agent2API 模块 · 清退型 Service Worker（v3.4.1 官方移除了 sw.js，
   但旧版 UI 注册的 SW 还留在用户浏览器里拦截请求、供旧缓存——
   浏览器更新 SW 时拉 sw.js 得 404，按规范旧 SW 继续控制页面，
   服务器上的修复永远到不了用户眼前）。
   本文件让旧 SW 退场：安装即接管（skipWaiting）→ 激活时删掉全部
   agent2api-mobile-* 旧缓存 → claim 客户端 → 导航重载让页面拿到新 JS。
   fetch 直连不拦截（服务器静态资源都是 no-cache + etag，天然新鲜）。
   CACHE 名带内容戳（patch-ui.sh 内容寻址更新）——内容变 → SW 更新
   → 旧缓存清退，形成闭环。 */
const CACHE = 'agent2api-mobile-pass-through';

self.addEventListener('install', () => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(
      keys.filter((k) => k.startsWith('agent2api-mobile')).map((k) => caches.delete(k))
    );
    await self.clients.claim();
    // 让已打开的页面重载一次——拿到服务器上的新 JS（本次清退的意义）
    const cs = await self.clients.matchAll({ type: 'window' });
    for (const c of cs) {
      try { await c.navigate(c.url); } catch (e) { /* 导航不了就算了 */ }
    }
  })());
});

self.addEventListener('fetch', (event) => {
  /* 直连：不拦截（no-cache + etag 保证新鲜） */
});
