/* Agent2API 手机端 · 自毁型 Service Worker。
 *
 * 存在的唯一目的：把上一版遗留的 SW 与全部旧缓存清掉，然后把自己注销。
 *
 * 为什么要自毁而不是继续缓存外壳：
 *   旧版把 m/mobile.js 当「外壳」用 stale-while-revalidate 缓存，于是换了
 *   APK 也照样供旧 JS —— 界面永远不变。任何「先给缓存、后台更新」的策略
 *   在调试期都是净负担。手机面板只在局域网用，去掉离线能力没有任何损失。
 */
const CACHE_PREFIX = 'agent2api-mobile';

self.addEventListener('install', () => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    // 删掉所有本前缀的缓存（含旧版本留下的）
    const keys = await caches.keys();
    await Promise.all(
      keys.filter((k) => k.startsWith(CACHE_PREFIX)).map((k) => caches.delete(k))
    );
    try { await self.registration.unregister(); } catch (e) { /* 注销失败无所谓 */ }
    await self.clients.claim();
    // 让已打开的页面重载一次，拿到新的脚本文件名
    const list = await self.clients.matchAll({ type: 'window' });
    for (const c of list) {
      try { await c.navigate(c.url); } catch (e) { /* 导航不了就算了 */ }
    }
  })());
});

/* 不拦截任何请求：全部走网络 */
self.addEventListener('fetch', () => {});
